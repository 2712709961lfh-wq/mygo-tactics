/* ============================================================================
 * characters.js — 角色素材层
 * ----------------------------------------------------------------------------
 * 五名我方角色使用项目内提供的四方向行走 / 待机 / 攻击 / 受伤 / 倒地素材。
 * 素材已经由 tools/prepare-character-assets.py 规整为 4 列 × 8 行、每格 80×96。
 *
 * 这个模块只负责“怎么画”，不修改战斗数据：
 *   - 地图 / 行动界面：drawMap
 *   - 编队头像、信息面板：drawPortrait
 *   - 编队姿态展示：drawPose
 *   - 战斗动画：drawBattlePose
 *
 * 如果图片加载失败，调用方可回退到 MyGO.Assets.drawUnit，游戏仍可运行。
 * ========================================================================== */
(function (global) {
  'use strict';

  const FRAME_W = 80;
  const FRAME_H = 96;
  const COLS = 4;
  const ROWS = 8;

  const UNIT_IDS = ['tomori', 'anon', 'rana', 'soyo', 'taki'];

  // 每个角色的素材文件名与配置 id 保持一致，方便替换。
  const SHEET_FILE = 'assets/characters/sprites/%s-sheet.png';
  const PORTRAIT_FILE = 'assets/characters/sprites/%s-portrait.png';
  const DOWN_FILE = 'assets/characters/sprites/%s-down.png';
  const WALK_FILE = 'assets/characters/walk/%s-walk.png';
  const IDLE_FILE = 'assets/characters/idle/%s-idle.png';
  const WALK_CELL = 128;
  const IDLE_W = 128;
  const IDLE_H = 142;

  // 行顺序由素材作者约定：四方向行走 → 攻击 → 受伤 → 倒地。
  const ROW = {
    walkDown: 0,
    walkRight: 1,
    walkUp: 2,
    walkLeft: 3,
    attack: 4,
    hurt: 5,
    down: 7
  };

  const sheets = Object.create(null);
  const portraits = Object.create(null);
  const downs = Object.create(null);
  const walkSheets = Object.create(null);
  const idleSheets = Object.create(null);
  let ready = false;
  let loading = null;

  function format(template, id) {
    return template.replace('%s', id);
  }

  function imageSource(id, kind) {
    const embedded = global.MYGO_CHARACTER_DATA;
    if (embedded && embedded[id]) {
      const key = kind === 'sheet' ? 'sheet' : kind === 'down' ? 'down' : kind === 'walk' ? 'walk' : kind === 'idle' ? 'idle' : 'portrait';
      if (embedded[id][key]) return embedded[id][key];
    }
    const file = kind === 'sheet' ? SHEET_FILE
      : kind === 'down' ? DOWN_FILE
      : kind === 'walk' ? WALK_FILE
      : kind === 'idle' ? IDLE_FILE
      : PORTRAIT_FILE;
    return format(file, id);
  }

  function loadImage(src) {
    return new Promise((resolve) => {
      const img = new Image();
      img.decoding = 'async';
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = src;
    });
  }

  /**
   * 预加载全部素材。调用一次即可；重复调用返回同一个 Promise。
   * @returns {Promise<boolean>} 是否全部加载成功
   */
  function load() {
    if (loading) return loading;
    loading = Promise.all(UNIT_IDS.map(async (id) => {
      const [sheet, portrait, down, walk, idle] = await Promise.all([
        loadImage(imageSource(id, 'sheet')),
        loadImage(imageSource(id, 'portrait')),
        loadImage(imageSource(id, 'down')),
        loadImage(imageSource(id, 'walk')),
        loadImage(imageSource(id, 'idle'))
      ]);
      if (sheet) sheets[id] = sheet;
      if (portrait) portraits[id] = portrait;
      if (down) downs[id] = down;
      if (walk) walkSheets[id] = walk;
      if (idle) idleSheets[id] = idle;
      return !!(sheet && portrait);
    })).then((results) => {
      ready = results.every(Boolean);
      if (!ready) {
        console.warn('[MyGO.Characters] 部分角色素材加载失败，将回退到程序化棋子。');
      }
      return ready;
    });
    return loading;
  }

  function has(id) {
    return !!(sheets[id] && portraits[id]);
  }

  function isReady() {
    return ready;
  }

  function facingRow(facing) {
    switch (facing) {
      case 'up': return ROW.walkUp;
      // 素材只画了朝左的侧面；朝右用同一行镜像，避免 3/4 正面看起来没转身。
      case 'right': return ROW.walkLeft;
      case 'left': return ROW.walkLeft;
      default: return ROW.walkDown;
    }
  }

  /**
   * 绘制一个 80×96 单元格中的角色。
   * @param {CanvasRenderingContext2D} ctx
   * @param {string} id
   * @param {number} x 脚底中心 x
   * @param {number} y 脚底 y
   * @param {number} height 目标高度
   * @param {object} options {state, facing, frame, flip}
   */
  function drawFrame(ctx, id, x, y, height, options) {
    const img = sheets[id];
    const opts = options || {};
    const state = opts.state || 'idle';

    // 倒地帧横跨两格，使用单独裁剪的 wide 图，避免被 80px 格子切断。
    if (state === 'down' && downs[id]) {
      const down = downs[id];
      const ratio = (down.naturalWidth || down.width) / (down.naturalHeight || down.height);
      let dh = height * 0.82;
      let dw = dh * ratio;
      // 倒地素材是横躺比例，必须按可用宽度再缩一次，避免在 58px 卡槽里被裁成两截。
      const maxW = opts.maxWidth || height * 1.15;
      if (dw > maxW) {
        dw = maxW;
        dh = dw / ratio;
      }
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(down, x - dw / 2, y - dh, dw, dh);
      ctx.restore();
      return true;
    }

    if (!img) return false;
    const facing = opts.facing || 'down';
    let row = facingRow(facing);
    let col = 0;

    if (state === 'walk' || state === 'idle') {
      row = facingRow(facing);
      col = state === 'walk' ? ((opts.frame || 0) % COLS) : 0;
    } else if (state === 'attack') {
      if (facing === 'left' || facing === 'right') {
        // 战斗中优先使用侧面行走行，保证攻击时面向对手。
        row = facingRow(facing);
        col = 1;
      } else {
        row = ROW.attack;
        col = Math.max(0, Math.min(3, opts.frame == null ? 1 : opts.frame));
      }
    } else if (state === 'hurt') {
      if (facing === 'left' || facing === 'right') {
        row = facingRow(facing);
        col = 2;
      } else {
        row = ROW.hurt;
        col = 0;
      }
    } else if (state === 'down') {
      row = ROW.down;
      col = 3;
    }

    const width = height * (FRAME_W / FRAME_H);
    const dx = x - width / 2;
    const dy = y - height;
    // 原始素材的侧面行实际朝左；朝右时水平翻转，朝左时保持原图。
    const sideState = state === 'idle' || state === 'walk' || state === 'attack' || state === 'hurt';
    const flip = (opts.flip ? 1 : 0) ^ (sideState && facing === 'right' ? 1 : 0);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    if (flip) {
      ctx.translate(x, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(img, col * FRAME_W, row * FRAME_H, FRAME_W, FRAME_H, -width / 2, dy, width, height);
    } else {
      ctx.drawImage(img, col * FRAME_W, row * FRAME_H, FRAME_W, FRAME_H, dx, dy, width, height);
    }
    ctx.restore();
    return true;
  }

  /**
   * 四方向站立图：2 列 × 2 行。
   * 按素材实际朝向：左上=下，右上=左，左下=上，右下=右。
   */
  function drawIdle(ctx, id, x, y, height, facing) {
    const img = idleSheets[id];
    if (!img) return false;
    const side = facing === 'left' || facing === 'right';
    const col = side ? 1 : 0;
    const row = facing === 'up' ? 1 : facing === 'right' ? 1 : 0;
    const h = height || 60;
    const w = Math.round(h * (IDLE_W / IDLE_H));
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, col * IDLE_W, row * IDLE_H, IDLE_W, IDLE_H, x - w / 2, y - h, w, h);
    ctx.restore();
    return true;
  }

  /**
   * 地图行走素材：3 列 × 4 行，行顺序为下 / 上 / 左 / 右。
   * 绿幕图已离线去背，右侧使用左行走行镜像。
   */
  function drawWalk(ctx, id, x, y, height, now, unit) {
    const img = walkSheets[id];
    if (!img) return false;
    const facing = unit.facing || 'down';
    const moving = !!(unit._walking);
    const phase = unit._spritePhase || 0;
    const tick = Math.floor((now + phase * 89) / 112);
    const frameSeq = [0, 1, 2, 1];
    const col = moving ? frameSeq[tick % frameSeq.length] : 0;
    const row = facing === 'up' ? 1 : (facing === 'left' || facing === 'right') ? 2 : 0;
    const h = height || 60;
    const w = h;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    if (facing === 'right') {
      ctx.translate(x, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(img, col * WALK_CELL, row * WALK_CELL, WALK_CELL, WALK_CELL, -w / 2, y - h, w, h);
    } else {
      ctx.drawImage(img, col * WALK_CELL, row * WALK_CELL, WALK_CELL, WALK_CELL, x - w / 2, y - h, w, h);
    }
    ctx.restore();
    return true;
  }

  /**
   * 地图单位：脚底对齐格子底边，带小地面阴影和行走循环。
   */
  function drawMap(ctx, unit, x, y, height, now, options) {
    const id = unit.id;
    if (!sheets[id]) return false;
    const opts = options || {};
    // _walkUntil 是兜底：即使动画回调被浏览器节流/中断，也不会永久停在奔跑帧。
    const moving = !!unit._walking && (!unit._walkUntil || now <= unit._walkUntil);
    const facing = unit.facing || 'down';
    const phase = unit._spritePhase || 0;
    const frame = moving ? Math.floor((now + phase * 97) / 118) % COLS : 0;
    const h = height || 60;
    const shadowW = h * 0.38;

    ctx.save();
    ctx.fillStyle = 'rgba(4, 8, 18, 0.34)';
    ctx.beginPath();
    ctx.ellipse(x, y + 1, shadowW / 2, h * 0.075, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // 移动使用绿幕行走图；停下后使用四方向站立图，双腿着地。
    if (moving && walkSheets[id]) {
      return drawWalk(ctx, id, x, y, h, now, unit);
    }
    if (!moving && idleSheets[id]) {
      return drawIdle(ctx, id, x, y, h, facing);
    }

    return drawFrame(ctx, id, x, y, h, {
      state: moving ? 'walk' : 'idle',
      facing,
      frame
    });
  }

  function drawBattlePose(ctx, unit, x, y, height, state, frame, facing) {
    return drawFrame(ctx, unit.id, x, y, height, {
      state: state || 'idle',
      // 战斗场景默认面向右侧；drawer 外层会对敌方做水平翻转。
      facing: facing || 'right',
      frame: frame == null ? 1 : frame,
      maxWidth: height * 0.92
    });
  }

  /**
   * 编队/信息面板头像。
   * @param {object} options {head:boolean}
   */
  function drawPortrait(ctx, id, x, y, w, h, options) {
    const img = portraits[id];
    if (!img) return false;
    const opts = options || {};
    ctx.save();
    ctx.imageSmoothingEnabled = false;

    if (opts.head) {
      // 头像裁切：取上半身，以 cover 方式填满方形区域。
      const sw = img.naturalWidth || img.width;
      const sh = Math.round((img.naturalHeight || img.height) * 0.54);
      const scale = Math.max(w / sw, h / sh);
      const dw = sw * scale;
      const dh = sh * scale;
      const dx = x + (w - dw) / 2;
      const dy = y + (h - dh) * 0.18;
      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.clip();
      ctx.drawImage(img, 0, 0, sw, sh, dx, dy, dw, dh);
    } else {
      // 全身像：contain，底部对齐。
      const sw = img.naturalWidth || img.width;
      const sh = img.naturalHeight || img.height;
      const scale = Math.min(w / sw, h / sh);
      const dw = sw * scale;
      const dh = sh * scale;
      ctx.drawImage(img, x + (w - dw) / 2, y + h - dh, dw, dh);
    }
    ctx.restore();
    return true;
  }

  /**
   * 编队页的动作预览条：同一角色的待机/攻击/受伤/倒地。
   */
  function drawPose(ctx, id, x, y, w, h, state, frame) {
    return drawFrame(ctx, id, x + w / 2, y + h, h, {
      state: state || 'idle',
      facing: 'down',
      frame: frame == null ? 0 : frame,
      maxWidth: w * 0.92
    });
  }

  global.MyGO = global.MyGO || {};
  global.MyGO.Characters = {
    UNIT_IDS,
    FRAME_W,
    FRAME_H,
    load,
    isReady,
    has,
    drawMap,
    drawBattlePose,
    drawPortrait,
    drawPose,
    drawFrame
  };
})(window);

/* ============================================================
 * config.js — 全局规则、地图、角色与武器数据
 * 所有数值集中在此处，方便后续平衡调整。
 * 使用普通 <script> 加载，因此挂载到 window.MyGO 命名空间。
 * ============================================================ */
(function (global) {
  'use strict';

  const MyGO = (global.MyGO = global.MyGO || {});

  /** 单个格子的像素尺寸。素材接口固定以 32×32 为基准。 */
  const TILE = 32;

  /**
   * 画布内部超采样倍率：逻辑坐标仍是 32px 一格，
   * 但实际 back-buffer 以 2× 绘制，放大到屏幕时像素边缘更干净。
   */
  const RENDER_SCALE = 2;

  /** 地图尺寸（单位：格）。24 × 16 的庭院，镜头可在棋盘内放大查看。 */
  const COLS = 24;
  const ROWS = 16;

  /**
   * 地图单位的绘制高度（逻辑像素）。角色素材为 80×96，
   * 按高度 60 等比缩放；横向约 50px，会略微溢出 32px 格子。
   */
  const SPRITE_SIZE = 60;

  /** 地形定义：移动消耗、闪避、守备、是否阻挡。 */
  const TERRAIN = {
    plain: {
      id: 'plain',
      name: '草地',
      moveCost: 1,
      avoid: 0,
      def: 0,
      blocked: false,
      desc: '无额外加成，移动消耗 1。'
    },
    road: {
      id: 'road', name: '花园小径', moveCost: 1, avoid: 0, def: 0, blocked: false,
      desc: '清晰的主路，移动消耗 1。'
    },
    plaza: {
      id: 'plaza', name: '内庭石坪', moveCost: 1, avoid: 0, def: 0, blocked: false,
      desc: '庭院石砖地面，移动消耗 1。'
    },
    forest: {
      id: 'forest',
      name: '森林',
      moveCost: 2,
      avoid: 20,
      def: 0,
      blocked: false,
      desc: '闪避 +20，移动消耗 2。'
    },
    mountain: {
      id: 'mountain',
      name: '山地',
      moveCost: 2,
      avoid: 0,
      def: 3,
      blocked: false,
      desc: '守备 +3，移动消耗 2。'
    },
    wall: {
      id: 'wall',
      name: '残垣',
      moveCost: Infinity,
      avoid: 0,
      def: 0,
      blocked: true,
      desc: '无法通行，也无法停留。'
    },
    gate: {
      id: 'gate',
      name: '庭院大门',
      moveCost: Infinity,
      avoid: 0,
      def: 0,
      blocked: true,
      desc: '被锁住的庭院门。击败携带钥匙的敌人后开启。'
    },
    gateOpen: {
      id: 'gateOpen',
      name: '开启的庭院门',
      moveCost: 1,
      avoid: 0,
      def: 0,
      blocked: false,
      desc: '门已开启，可以进入庭院。'
    },
    water: {
      id: 'water',
      name: '深水',
      moveCost: Infinity,
      avoid: 0,
      def: 0,
      blocked: true,
      desc: '水流湍急，无法通行。'
    },
    bridge: {
      id: 'bridge',
      name: '石桥',
      moveCost: 1,
      avoid: 0,
      def: 0,
      blocked: false,
      desc: '横跨河面的石桥，移动消耗 1。'
    }
  };

  /**
   * 武器三角：剑 > 斧 > 枪 > 剑。
   * 克制修正直接乘在“武器威力”上，而不是平加固定伤害：
   *   优势：威力 × 1.2；劣势：威力 × 0.8。
   * 命中仍为 +15 / -15。弓与魔法不参与三角，但拥有 2~3 格射程。
   */
  const TRIANGLE = {
    sword: { beats: 'axe', name: '剑' },
    axe: { beats: 'lance', name: '斧' },
    lance: { beats: 'sword', name: '枪' }
  };

  const TRIANGLE_BONUS = {
    /** 克制方武器威力倍率。 */
    advantageMultiplier: 1.2,
    /** 被克制方武器威力倍率。 */
    disadvantageMultiplier: 0.8,
    /** 命中修正。 */
    hit: 15,
    /** 对“有效目标”的默认威力倍率，可在武器 effectiveAgainst 中启用。 */
    effectivenessMultiplier: 1.5
  };

  /** 战斗常数。暴击为 2 倍伤害；不设反击，详见 README。 */
  const COMBAT = {
    critMultiplier: 2,
    minHit: 5,
    maxHit: 100,
    minDamage: 1,
    speedAvoidFactor: 1.5,
    criticalDamage: 2
  };

  /** 第一关：西南集结 → 双桥花园 → 东庭钥匙守卫 → 北侧封闭内庭。
   * 每行严格 24 格，画面和寻路共用这份数据，禁止静默截断或补出生格。 */
  const MAP_CHARS = [
    'ffffffffwwffffffffffffff',
    'f######.ww.############f',
    'f######.ww.#pppppppppp#f',
    'f######.ww.#pppppppppp#f',
    'f######.ww.#ffppwwppff#f',
    'f.......ww.#ffppwwppff#f',
    'f.ff.rrrbb.#pppppppppp#f',
    'f.ffmrrrbb.#pppppppppp#f',
    'ffff.rf.ww.#####GG#####f',
    'fff..rm.ww......rr.....f',
    'f..rrrr.ww..m.f.rr..ff.f',
    'f...rrrrbbrrrrrrrrrrrr.f',
    'f...rrrrbbrrrrrrrrrrrrff',
    'f.......ww.........mrrff',
    'f.ff.ff.ww.ff....ff.rrff',
    'f....ff.ww.ff..........f'
  ];
  const MAP_DECOR = [];
  const STAGE_ONE_SPAWNS = {
    tomori: { x: 4, y: 11 },
    anon: { x: 2, y: 12 },
    rana: { x: 5, y: 12 },
    soyo: { x: 3, y: 13 },
    taki: { x: 3, y: 10 },
    shadow_blade_1: { x: 6, y: 6 },
    shadow_axe: { x: 12, y: 11 },
    shadow_blade_2: { x: 20, y: 14 },
    shadow_bow: { x: 21, y: 11 },
    shadow_lance: { x: 18, y: 6 },
    conductor: { x: 16, y: 2 }
  };
  const MAP_REVISION = 2;

  const CHAR_TO_TERRAIN = {
    '.': 'plain',
    f: 'forest',
    m: 'mountain',
    '#': 'wall',
    G: 'gate',
    w: 'water',
    b: 'bridge',
    r: 'road',
    p: 'plaza'
  };

  /** 将字符地图转换为二维地形 id 数组。 */
  function buildTerrainGrid(chars) {
    return (chars || MAP_CHARS).map((row) =>
      row.split('').map((ch) => CHAR_TO_TERRAIN[ch] || 'plain')
    );
  }

  /**
   * 第二章「月下回廊」。
   * 中央横向河流把战场切成南北两岸，只有两座窄桥可以通过；
   * 北岸是王座前厅，南岸是树林与断墙，形成第二关的推进路线。
   */
  const STAGE_TWO_MAP = [
    'mfmmmffffffffffffffmmmfm',
    'mf...##############...fm',
    'mf...#............#...fm',
    'mf...#............#...fm',
    'mf...#............#...fm',
    'mf...#####....#####...fm',
    'mf.ff..............ff.fm',
    'wwwwwwbbwwwwwwwwbbwwwwww',
    'wwwwwwbbwwwwwwwwbbwwwwww',
    'wwwwwwbbwwwwwwwwbbwwwwww',
    '..f..................f..',
    '....m..............m....',
    '.....###........###.....',
    '.........ff..ff.........',
    '........................',
    'fffffffff.......ffffffff'
  ];

  const STAGE_TWO_DECOR = [];

  const STAGE_TWO = {
    id: 'mission-02',
    chapter: 'MISSION 02',
    chapterJp: '第二话',
    chapterEn: 'CHAPTER 02',
    title: '月下回廊',
    mapName: '月见桥',
    subtitle: '桥的另一端，仍有未唱完的歌。',
    objective: '渡过月见桥，击破影之指挥与全部敌人',
    gateHint: '',
    turnLimit: 0,
    mapChars: STAGE_TWO_MAP,
    terrain: buildTerrainGrid(STAGE_TWO_MAP),
    decor: STAGE_TWO_DECOR,
    spawns: {
      anon: { x: 3, y: 13 },
      soyo: { x: 4, y: 14 },
      tomori: { x: 5, y: 13 },
      rana: { x: 6, y: 14 },
      taki: { x: 7, y: 13 },
      shadow_blade_1: { x: 7, y: 10 },
      shadow_lance: { x: 13, y: 4, dormant: false },
      shadow_bow: { x: 16, y: 10, key: false },
      shadow_axe: { x: 10, y: 11 },
      shadow_blade_2: { x: 18, y: 11 },
      conductor: { x: 11, y: 2, dormant: false }
    }
  };

  /**
   * 武器数据。
   * damageType 决定攻击使用力量还是魔力，也决定目标用守备还是魔防减伤：
   *   physical -> 力量 / 守备；magic -> 魔力 / 魔防。
   * effectiveAgainst 可填目标 tags（如 ['armor','flying']），命中时威力再乘
   * TRIANGLE_BONUS.effectivenessMultiplier。
   * 魔法武器可额外设置 element / elementName，战斗演出会据此切换魔法球颜色：
   *   fire 火红、ice 冰蓝、wind 翠绿、thunder 金黄、dark 紫黑、light 白金。
   */
  const WEAPONS = {
    starblade: {
      id: 'starblade',
      name: '星屑之剑',
      type: 'sword',
      range: [1, 1],
      might: 5,
      hit: 5,
      crit: 5,
      damageType: 'physical',
      color: '#ff9ec7'
    },
    spotlightBow: {
      id: 'spotlightBow',
      name: '追光之弓',
      type: 'bow',
      range: [2, 3],
      might: 4,
      hit: 10,
      crit: 0,
      damageType: 'physical',
      color: '#ffd166'
    },
    strayLance: {
      id: 'strayLance',
      name: '野猫之枪',
      type: 'lance',
      range: [1, 1],
      might: 5,
      hit: 5,
      crit: 5,
      damageType: 'physical',
      color: '#7ee0d2'
    },
    moonwoodStaff: {
      id: 'moonwoodStaff',
      name: '月森之杖',
      type: 'tome',
      range: [2, 3],
      might: 6,
      hit: 10,
      crit: 5,
      damageType: 'magic',
      element: 'ice',
      elementName: '冰',
      color: '#b79cff'
    },
    heartbeatAxe: {
      id: 'heartbeatAxe',
      name: '鼓动之斧',
      type: 'axe',
      range: [1, 1],
      might: 7,
      hit: 0,
      crit: 0,
      damageType: 'physical',
      color: '#ff7a7a'
    },
    shadowBlade: {
      id: 'shadowBlade',
      name: '残缺之刃',
      type: 'sword',
      range: [1, 1],
      might: 4,
      hit: 0,
      crit: 0,
      damageType: 'physical',
      color: '#9d7cff'
    },
    shadowLance: {
      id: 'shadowLance',
      name: '回声之枪',
      type: 'lance',
      range: [1, 1],
      might: 5,
      hit: 0,
      crit: 0,
      damageType: 'physical',
      color: '#9d7cff'
    },
    shadowBow: {
      id: 'shadowBow',
      name: '空响之弓',
      type: 'bow',
      range: [2, 3],
      might: 3,
      hit: 0,
      crit: 0,
      damageType: 'physical',
      color: '#9d7cff'
    },
    shadowAxe: {
      id: 'shadowAxe',
      name: '沉默之斧',
      type: 'axe',
      range: [1, 1],
      might: 6,
      hit: 0,
      crit: 0,
      damageType: 'physical',
      color: '#9d7cff'
    },
    conductorBaton: {
      id: 'conductorBaton',
      name: '无面指挥棒',
      type: 'tome',
      range: [2, 3],
      might: 7,
      hit: 5,
      crit: 0,
      damageType: 'magic',
      element: 'fire',
      elementName: '火',
      color: '#ff6b8a'
    }
  };

  /**
   * 角色模板。x/y 为出生格。
   * art 字段交给 assets.js 生成 32px 像素占位图；替换素材时无需改战斗数据。
   */
  const UNITS = [
    {
      id: 'tomori',
      name: '高松灯',
      shortName: '灯',
      side: 'player',
      className: '剑士',
      level: 5,
      gender: '女',
      maxHp: 26,
      str: 10,
      mag: 5,
      spd: 9,
      def: 5,
      res: 4,
      hit: 90,
      crit: 10,
      move: 5,
      weapon: 'starblade',
      x: 2,
      y: 5,
      quote: '即使迷路，也要把这首歌传达出去。',
      art: {
        kind: 'hero',
        hair: '#d8cfd6',
        hairDark: '#8d8392',
        hairStyle: 'bob',
        outfit: '#2d3147',
        outfitDark: '#1b1d2c',
        accent: '#ff8fbd',
        skin: '#f4cfc0',
        eye: '#6d4d75'
      }
    },
    {
      id: 'anon',
      name: '千早爱音',
      shortName: '爱音',
      side: 'player',
      className: '弓手',
      level: 5,
      gender: '女',
      maxHp: 22,
      str: 9,
      mag: 6,
      spd: 11,
      def: 3,
      res: 5,
      hit: 85,
      crit: 12,
      move: 5,
      weapon: 'spotlightBow',
      x: 1,
      y: 4,
      quote: '既然要组乐队，当然要站在最亮的地方！',
      art: {
        kind: 'hero',
        hair: '#f4a8c4',
        hairDark: '#bc6e8d',
        hairStyle: 'long',
        outfit: '#f0e8ee',
        outfitDark: '#b8a7b3',
        accent: '#ff5f9e',
        skin: '#f8d8c8',
        eye: '#88506a'
      }
    },
    {
      id: 'rana',
      name: '要乐奈',
      shortName: '乐奈',
      side: 'player',
      className: '枪骑士',
      level: 5,
      gender: '女',
      maxHp: 24,
      str: 10,
      mag: 4,
      spd: 12,
      def: 4,
      res: 3,
      hit: 88,
      crit: 8,
      move: 6,
      weapon: 'strayLance',
      x: 1,
      y: 7,
      quote: '有趣的女人。……抹茶芭菲，吃吗？',
      art: {
        kind: 'hero',
        hair: '#f2f0e6',
        hairDark: '#b8b6a8',
        hairStyle: 'messy',
        outfit: '#22212d',
        outfitDark: '#111118',
        accent: '#6de3d4',
        skin: '#f5d6c4',
        eye: '#d9b44a'
      }
    },
    {
      id: 'soyo',
      name: '长崎爽世',
      shortName: '爽世',
      side: 'player',
      className: '法师',
      level: 5,
      gender: '女',
      maxHp: 20,
      str: 4,
      mag: 12,
      spd: 8,
      def: 2,
      res: 9,
      hit: 92,
      crit: 8,
      move: 4,
      weapon: 'moonwoodStaff',
      x: 2,
      y: 8,
      quote: '为了不让大家再次走散……这次，我会好好说清楚。',
      art: {
        kind: 'hero',
        hair: '#c8a678',
        hairDark: '#8c6f4c',
        hairStyle: 'long',
        outfit: '#3d5a4e',
        outfitDark: '#22332c',
        accent: '#d8c28c',
        skin: '#f7d9c9',
        eye: '#7b5d45'
      }
    },
    {
      id: 'taki',
      name: '椎名立希',
      shortName: '立希',
      side: 'player',
      className: '斧战士',
      level: 5,
      gender: '女',
      maxHp: 32,
      str: 12,
      mag: 3,
      spd: 5,
      def: 8,
      res: 3,
      hit: 78,
      crit: 6,
      move: 4,
      weapon: 'heartbeatAxe',
      x: 1,
      y: 2,
      quote: '别拖后腿。节奏，由我来守住。',
      art: {
        kind: 'hero',
        hair: '#2c2733',
        hairDark: '#151219',
        hairStyle: 'short',
        outfit: '#2b1c24',
        outfitDark: '#170e14',
        accent: '#ff6b6b',
        skin: '#f2cfbd',
        eye: '#b86a7b'
      }
    },
    {
      id: 'shadow_blade_1',
      name: '迷途回声·刃',
      shortName: '影刃',
      side: 'enemy',
      className: '影剑士',
      level: 4,
      maxHp: 20,
      str: 8,
      mag: 2,
      spd: 8,
      def: 3,
      res: 2,
      hit: 80,
      crit: 5,
      move: 4,
      weapon: 'shadowBlade',
      x: 17,
      y: 2,
      quote: '……回来……',
      art: {
        kind: 'shadow',
        hair: '#5b4b83',
        hairDark: '#2d2445',
        hairStyle: 'bob',
        outfit: '#342c50',
        outfitDark: '#191429',
        accent: '#a88cff',
        skin: '#6f6391',
        eye: '#ff7ea8'
      }
    },
    {
      id: 'shadow_lance',
      name: '迷途回声·枪',
      shortName: '影枪',
      side: 'enemy',
      className: '影枪兵',
      level: 4,
      maxHp: 22,
      str: 9,
      mag: 3,
      spd: 7,
      def: 5,
      res: 2,
      hit: 80,
      crit: 3,
      move: 4,
      weapon: 'shadowLance',
      x: 13,
      y: 8,
      dormant: true,
      quote: '……不要……忘记……',
      art: {
        kind: 'shadow',
        hair: '#6a4b83',
        hairDark: '#332445',
        hairStyle: 'short',
        outfit: '#3a2b50',
        outfitDark: '#1b1429',
        accent: '#9d7cff',
        skin: '#726391',
        eye: '#ff8aa8'
      }
    },
    {
      id: 'shadow_bow',
      name: '迷途回声·弓',
      shortName: '影弓',
      side: 'enemy',
      className: '影弓手',
      level: 4,
      maxHp: 18,
      str: 8,
      mag: 2,
      spd: 8,
      def: 2,
      res: 2,
      hit: 78,
      crit: 5,
      move: 4,
      weapon: 'shadowBow',
      x: 18,
      y: 8,
      key: true,
      quote: '……听不见……',
      art: {
        kind: 'shadow',
        hair: '#4b5b83',
        hairDark: '#243045',
        hairStyle: 'ponytail',
        outfit: '#2b3a50',
        outfitDark: '#141d29',
        accent: '#7ec8ff',
        skin: '#647391',
        eye: '#ff9eb8'
      }
    },
    {
      id: 'shadow_axe',
      name: '迷途回声·斧',
      shortName: '影斧',
      side: 'enemy',
      className: '影斧兵',
      level: 4,
      maxHp: 26,
      str: 11,
      mag: 2,
      spd: 4,
      def: 6,
      res: 1,
      hit: 72,
      crit: 2,
      move: 3,
      weapon: 'shadowAxe',
      x: 16,
      y: 13,
      quote: '……好重……',
      art: {
        kind: 'shadow',
        hair: '#5b3b5b',
        hairDark: '#301d30',
        hairStyle: 'messy',
        outfit: '#3b2742',
        outfitDark: '#1d1322',
        accent: '#d17cff',
        skin: '#715b75',
        eye: '#ff7ea8'
      }
    },
    {
      id: 'shadow_blade_2',
      name: '迷途回声·刃',
      shortName: '影刃',
      side: 'enemy',
      className: '影剑士',
      level: 4,
      maxHp: 20,
      str: 8,
      mag: 2,
      spd: 8,
      def: 3,
      res: 2,
      hit: 80,
      crit: 5,
      move: 4,
      weapon: 'shadowBlade',
      x: 21,
      y: 14,
      quote: '……回来……',
      art: {
        kind: 'shadow',
        hair: '#5b4b83',
        hairDark: '#2d2445',
        hairStyle: 'bob',
        outfit: '#342c50',
        outfitDark: '#191429',
        accent: '#a88cff',
        skin: '#6f6391',
        eye: '#ff7ea8'
      }
    },
    {
      id: 'conductor',
      name: '无面指挥家',
      shortName: '指挥家',
      side: 'enemy',
      className: '迷途首领',
      level: 8,
      maxHp: 38,
      str: 5,
      mag: 14,
      spd: 7,
      def: 6,
      res: 8,
      hit: 90,
      crit: 8,
      move: 4,
      weapon: 'conductorBaton',
      x: 12,
      y: 4,
      boss: true,
      dormant: true,
      quote: '迷路的孩子，留在这里就好。',
      art: {
        kind: 'boss',
        hair: '#2a1838',
        hairDark: '#120a1a',
        hairStyle: 'long',
        outfit: '#271a38',
        outfitDark: '#0e0916',
        accent: '#ff4f8b',
        skin: '#b9a5c9',
        eye: '#ff3f7f'
      }
    }
  ];

  /** 关卡信息。 */
  const MISSION = {
    id: 'mission-01',
    chapter: 'MISSION 01',
    chapterJp: '第一话',
    chapterEn: 'CHAPTER 01',
    title: '黄昏的迷途庭院',
    objective: '击破全部敌人 · 先夺取钥匙，开启内庭南门',
    subtitle: '在封闭心声的庭院，找回第一道回声。',
    mapName: '迷途庭院',
    gateHint: '沿双桥穿过水渠，击破东庭携带金钥匙的影弓；北侧内庭南门随之开启。',
    turnLimit: 0
  };

  /** 操作/提示文案。 */
  const TEXT = {
    hints: {
      idle: '点击我方单位开始行动 · 点击敌方单位查看情报',
      move: '点击蓝色格子移动 · 右键 / Esc 取消选择',
      action: '选择行动：攻击、待机，或取消刚才的移动',
      attack: '点击红色范围内的敌方单位 · 右键 / Esc 返回',
      enemy: '敌方正在行动……',
      busy: '结算中……'
    }
  };

  // Narrative fragments for this inner-world adaptation; no additional combat stats.
  const CHARACTER_STORIES = {
    tomori: '那些来不及说出口的话，被她一一留在心底。即使害怕再次失去，她仍想把同伴的声音带回去。',
    anon: '笑容能遮住孤独，却不能让它消失。她想在这段旅程里，找到一个不必假装坚强的位置。',
    rana: '她追逐心底微弱的响动，在寂静中寻找方向。比起解释，她选择留在同伴身边。',
    soyo: '她握着关于过去的碎片，不敢松手。穿过庭院之后，她也许能学会面对离开与新的相遇。',
    taki: '她把脆弱藏在锋利的言语后面。只要还有需要守护的人，她就不会停下脚步。'
  };

  MyGO.CONFIG = {
    CHARACTER_STORIES,
    TILE,
    RENDER_SCALE,
    SPRITE_SIZE,
    COLS,
    ROWS,
    TERRAIN,
    TRIANGLE,
    TRIANGLE_BONUS,
    COMBAT,
    MAP_CHARS,
    MAP_TERRAIN: buildTerrainGrid(),
    MAP_DECOR,
    STAGE_ONE_SPAWNS,
    MAP_REVISION,
    WEAPONS,
    UNITS,
    MISSION,
    STAGE_TWO,
    buildTerrainGrid,
    TEXT,
    SAVE_KEY: 'mygo_tactics_save_v1',
    SAVE_VERSION: 1
  };
})(window);

# 高松灯持剑动作（v3.5）

作者提供原图：`D:/Gemini_Generated_Image_oc56kfoc56kfoc56.jpg`，1278×832。未经修改的副本保存在 `source/tomori-sword-original.jpg`。该角色素材由用户提供，不属于项目其他素材的 CC0 授权范围。

运行 `python tools/prepare-tomori-actions.py`（需要 Pillow）重新生成：

- `tomori-actions.png`：8 列×5 行，每格 256×160。待机 5 帧、持剑行走 8 帧、挥剑 4 帧、受伤 4 帧、倒地 5 帧，共 26 帧；其余格为空。
- `tomori-actions.json`：脚底锚点 `(112,140)`、身体参考高 112 和各行帧数。运行时配置在 `src/characters.js`，切图规格变化时需同步。
- `../sprites/tomori-down.png`：最终倒地姿态，包含随人物倒落的剑。
- `docs/previews/tomori-actions-dark.png`、`tomori-actions-light.png`：深浅背景逐帧检查图。
- `docs/previews/tomori-actions.gif`：五组动作预览。

## 素材整理

以亮绿背景与裙装的绿色差异做软透明遮罩，恢复剑光的半透明边缘，并仅在轮廓边缘去除绿幕溢色。保留原始人物与服装造型，没有重新生成或重画角色。按各帧人物中心与地面位置对齐，倒地中腾空姿态保留相对地面的高度。清理相邻帧混入的头发和剑尖；原图右下角最后一把单独的剑没有作为额外人物帧。

## 游戏内表现

战斗中使用新待机循环；接近和撤回播放持剑行走；四帧攻击按准备、举剑、挥砍、收势推进，挥砍帧在 `IMPACT_T = 0.58` 命中时刻出现。受伤播放四帧后恢复待机；被击破时播放倒地五帧并保持最后一帧，停止呼吸浮动与后仰。原图没有跳跃闪避行，闪避使用现有侧移演出。

原图只有一个侧向的行走序列，因此地图继续使用现有四方向待机和行走素材。头像、档案立绘和标题合照沿用原版，保持五人的界面形象一致。编队页的待机／攻击／受伤／倒地预览使用新动作。战斗规则、属性和装备图鉴未变。

## 预览

`index.html` 或 `standalone.html` 后加：

| 参数 | 表现 |
| --- | --- |
| `?battle-demo=tomori` | 持剑接近与普通挥砍 |
| `?battle-demo=tomori-crit` | 暴击挥砍 |
| `?battle-demo=tomori-hurt` | 灯受伤 |
| `?battle-demo=tomori-dodge` | 灯闪避侧移 |
| `?battle-demo=tomori-down` | 灯倒地 |

末尾加 `-freeze` 定格检查，如 `?battle-demo=tomori-freeze`、`?battle-demo=tomori-down-freeze`。预览不扣除实际 HP，也不写入存档。

运行 `node tests/test-character-actions.js` 验证两名自定义角色素材、帧数、锚点、朝向、地图四方向素材保留、攻击命中时序、受伤恢复、倒地末帧保持与爽世投射物。运行 `node build-standalone.js` 更新单文件。替换前相关源码与灯的头像／倒地素材保存在 `backups/before-tomori-actions-20261111.zip`。

"""Prepare the author's Tomori sword sheet without repainting the character.

Requires Pillow. Keeps the dark green skirt, removes the bright JPEG green
matte, and aligns every pose to a common foot pivot. Source is kept unchanged.
"""
from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/characters/actions'
source = Image.open(OUT / 'source/tomori-sword-original.jpg').convert('RGB')
assert source.size == (1278, 832), 'Re-measure crops for a different source'

# The skirt has G < 110 and only modest green excess; the screen has G ~168
# and excess ~103. A soft matte also retains the pale semitransparent slash.
keyed = Image.new('RGBA', source.size)
pixels = []
for r, g, b in source.get_flattened_data():
    excess = g - max(r, b)
    alpha = max(0., min(1., (96 - excess) / 65))
    if alpha < .035:
        pixels.append((0, 0, 0, 0))
        continue
    if alpha < 1:
        # Unmix the green screen rather than darkening the light sword trail.
        r, g, b = [round(max(0, min(255, (c - (1-alpha)*bg)/alpha)))
                   for c, bg in zip((r, g, b), (64, 168, 48))]
        g = min(g, max(r, b) + 10)
    pixels.append((r, g, b, round(alpha*255)))
keyed.putdata(pixels)
# Despill only the outer two pixels. Interior olive clothing stays untouched.
edge = keyed.getchannel('A').filter(ImageFilter.MinFilter(5))
keyed.putdata([(r,min(g,max(r,b)+5),b,a) if e < 240 and g > max(r,b)+8
               else (r,g,b,a) for (r,g,b,a),e in zip(pixels,edge.get_flattened_data())])

CW, CH, AX, AY, BODY_H = 256, 160, 112, 140, 112
atlas = Image.new('RGBA', (CW*8, CH*5))
# Each entry has a measured body pivot and explicit crop, retaining sword tips.
rows = [
    ('idle', 0, 138, [(x, (x-38, 24, x+39, 146)) for x in [230,369,508,647,786]]),
    ('walk', 1, 307, [(x, (x-40, 183, min(1278,x+65), 315))
                      for x in [228,367,506,645,784,923,1062,1201]]),
    ('attack', 2, 466, [(235,(195,345,323,475)), (380,(331,345,426,475)),
                       (520,(467,345,623,475)), (682,(623,345,767,475))]),
    ('hurt', 3, 620, [(x,(x-51,502,x+46,628)) for x in [235,380,520,660]]),
    ('down', 4, 774, [(230,(185,650,298,782)), (366,(297,650,447,782)),
                     (490,(430,650,534,766)), (634,(528,650,700,782)),
                     (810,(701,650,874,782))]),
]
frames = {}
for name, row, floor, crops in rows:
    for col, (pivot, box) in enumerate(crops):
        cell = Image.new('RGBA', (CW,CH))
        crop = keyed.crop(box)
        if name == 'down' and col == 1:
            # The next airborne head intrudes above the loose sword tip.
            ImageDraw.Draw(crop).rectangle((400-box[0],0,crop.width,747-box[1]),fill=(0,0,0,0))
        if name == 'down' and col == 2:
            ImageDraw.Draw(crop).rectangle((0,744-box[1],445-box[0],crop.height),fill=(0,0,0,0))
        cell.alpha_composite(crop, (AX+box[0]-pivot, AY+box[1]-floor))
        atlas.alpha_composite(cell, (col*CW,row*CH))
    frames[name] = {'row':row,'count':len(crops)}
atlas.save(OUT / 'tomori-actions.png', optimize=True)
meta = {'cellWidth':CW,'cellHeight':CH,'anchorX':AX,'anchorY':AY,
        'bodyHeight':BODY_H,'frames':frames,'sourceFacing':'right',
        'source':'source/tomori-sword-original.jpg'}
(OUT/'tomori-actions.json').write_text(json.dumps(meta,indent=2)+'\n','utf-8')
down = atlas.crop((4*CW,4*CH,5*CW,5*CH))
down.crop(down.getbbox()).save(ROOT/'assets/characters/sprites/tomori-down.png')

PREVIEW = ROOT/'docs/previews'
font = ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',16)
for theme,bg,ink in [('dark','#182431','#ead9ba'),('light','#e9e2d2','#263446')]:
    sheet = Image.new('RGB',(CW*8,CH*5+40),bg)
    draw = ImageDraw.Draw(sheet)
    for name,row,floor,crops in rows:
        draw.text((8,row*CH+4),name.upper(),font=font,fill=ink)
        draw.line((0,row*CH+AY+18,CW*8,row*CH+AY+18),fill='#72818b')
        for col in range(len(crops)):
            cell = atlas.crop((col*CW,row*CH,(col+1)*CW,(row+1)*CH))
            sheet.paste(cell,(col*CW,row*CH+18),cell)
            draw.text((col*CW+6,row*CH+26),str(col+1),font=font,fill=ink)
    sheet.save(PREVIEW/f'tomori-actions-{theme}.png')

# One simultaneous panel per action, with death progressing once then holding.
animations = []
for tick in range(40):
    preview = Image.new('RGB',(CW*5,CH+44),'#182431')
    draw = ImageDraw.Draw(preview)
    for index,(name,row,floor,crops) in enumerate(rows):
        count = len(crops)
        frame = tick % count if name in ('idle','walk') else min(count-1,max(0,(tick%20)-3)//2)
        cell = atlas.crop((frame*CW,row*CH,(frame+1)*CW,(row+1)*CH))
        preview.paste(cell,(index*CW,34),cell)
        draw.text((index*CW+12,8),f'{name.upper()} / {frame+1}',font=font,fill='#ead9ba')
    animations.append(preview)
animations[0].save(PREVIEW/'tomori-actions.gif',save_all=True,
    append_images=animations[1:],duration=100,loop=0,disposal=2)
print('Prepared Tomori: 26 transparent frames (5 idle, 8 walk, 4 attack, 4 hurt, 5 down).')

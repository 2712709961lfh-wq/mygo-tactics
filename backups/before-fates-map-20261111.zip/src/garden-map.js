/* 第一关专用的分层地图画笔。地形、岸线、城墙均读取实际 map.tiles。
 * Kenney Tiny Town / Tiny Dungeon (CC0)，来源与许可证见 docs/MAP-REMAKE.md。
 * 经典脚本、无网络依赖，file:// 与单文件版使用同一套绘制逻辑。 */
(function (global) {
  'use strict';
  const MyGO = global.MyGO;
  const S = MyGO.CONFIG.TILE;
  const sheets = {};
  const paths = {
    gardenTown: 'assets/terrain/kenney/tiny-town/tilemap_packed.png',
    gardenDungeon: 'assets/terrain/kenney/tiny-dungeon/tilemap_packed.png'
  };

  function load() {
    return Promise.all(Object.keys(paths).map(key => new Promise(resolve => {
      const img = new Image();
      img.onload = () => { sheets[key] = img; resolve(true); };
      img.onerror = () => resolve(false);
      img.src = (global.MYGO_MAP_DATA || {})[key] || paths[key];
    })));
  }
  function box(c, x, y, w, h, color) {
    c.fillStyle = color; c.fillRect(x, y, w, h);
  }
  function seed(x, y, n) {
    let a = Math.imul(x + 17, 374761393) ^ Math.imul(y + 31, 668265263) ^ Math.imul(n + 7, 1442695041);
    a = Math.imul(a ^ (a >>> 13), 1274126177);
    return (a ^ (a >>> 16)) >>> 0;
  }
  function sprite(c, id, x, y, w, h, dungeon) {
    const img = sheets[dungeon ? 'gardenDungeon' : 'gardenTown'];
    if (!img) return false;
    c.drawImage(img, (id % 12) * 16, Math.floor(id / 12) * 16, 16, 16, x, y, w || S, h || S);
    return true;
  }
  function at(map, x, y) {
    return map.tiles[y] && map.tiles[y][x];
  }
  function stone(type) { return type === 'wall' || type === 'gate' || type === 'gateOpen'; }
  function water(type) { return type === 'water' || type === 'bridge'; }
  function ground(c, x, y, gx, gy) {
    const colors = ['#70845a', '#74875c', '#76885d', '#718359'];
    box(c, x, y, S, S, colors[seed(gx, gy, 1) % colors.length]);
    for (let i = 0; i < 28; i++) {
      const h = seed(gx, gy, i + 8), dx = h % 30, dy = (h >>> 9) % 30;
      box(c, x + dx, y + dy, 2, 1, i % 3 ? '#829665' : '#61764d');
      if (i % 7 === 0) box(c, x + dx, y + dy - 1, 1, 3, '#93a472');
    }
    if (seed(gx, gy, 91) % 5 === 0) {
      box(c, x + 24, y + 10, 1, 3, '#556b48');
      box(c, x + 23, y + 9, 3, 2, '#d5bf93');
    }
  }
  function road(c, map, gx, gy, x, y) {
    const connected = t => t === 'road' || t === 'bridge' || t === 'gate' || t === 'gateOpen';
    const l = connected(at(map, gx - 1, gy)) ? 0 : 3;
    const r = connected(at(map, gx + 1, gy)) ? 0 : 3;
    const t = connected(at(map, gx, gy - 1)) ? 0 : 3;
    const b = connected(at(map, gx, gy + 1)) ? 0 : 3;
    box(c, x + l, y + t, S - l - r, S - t - b, '#b39e76');
    box(c, x + l, y + t, S - l - r, 1, '#c7b58b');
    for (let i = 0; i < 12; i++) {
      const h = seed(gx, gy, i + 100);
      box(c, x + 4 + h % 24, y + 4 + (h >>> 12) % 24, 2 + h % 2, 1, i % 3 ? '#bfa981' : '#958668');
    }
    if (seed(gx, gy, 3) % 4 === 0) {
      box(c, x + 10, y + 21, 9, 4, '#918b76');
      box(c, x + 10, y + 20, 8, 3, '#c9bfa0');
    }
  }
  function paving(c, x, y, gx, gy) {
    box(c, x, y, S, S, '#777f7b');
    for (let yy = 0; yy < 4; yy++) {
      for (let xx = 0; xx < 2; xx++) {
        const dx = x + xx * 16, dy = y + yy * 8;
        box(c, dx + 1, dy + 1, 14, 6, seed(gx + xx, gy + yy, 34) % 3 ? '#aeb0a0' : '#a0a998');
        box(c, dx + 1, dy + 1, 14, 1, '#c2c3ae');
      }
    }
    if ((gx + gy) % 4 === 0) box(c, x + 2, y + 30, 6, 1, '#6c845e');
  }
  function river(c, map, gx, gy, x, y) {
    box(c, x, y, S, S, '#315b63');
    box(c, x + 2, y, S - 4, S, '#3b7074');
    for (let i = 0; i < 8; i++) {
      const h = seed(gx, gy, i + 220);
      box(c, x + 3 + h % 21, y + 3 + (h >>> 12) % 26, 3 + h % 7, 1, i % 2 ? '#598d88' : '#457d7e');
    }
    if (!water(at(map, gx - 1, gy))) {
      box(c, x, y, 4, S, '#434f45');box(c, x, y, 2, S, '#a09e7c');box(c, x + 4, y, 1, S, '#80a091');
    }
    if (!water(at(map, gx + 1, gy))) {
      box(c, x + 28, y, 4, S, '#434f45');box(c, x + 30, y, 2, S, '#a09e7c');box(c, x + 27, y, 1, S, '#80a091');
    }
    if (!water(at(map, gx, gy - 1))) box(c, x, y, S, 3, '#aaa98b');
    if (!water(at(map, gx, gy + 1))) box(c, x, y + 29, S, 3, '#6a725b');
  }
  function bridge(c, map, gx, gy, x, y) {
    river(c, map, gx, gy, x, y);
    box(c, x, y, S, S, '#514839');
    for (let i = 0; i < 4; i++) {
      box(c, x + i * 8 + 1, y + 1, 6, 30, '#b69a6d');
      box(c, x + i * 8 + 1, y + 2, 1, 28, '#d0b586');
      box(c, x + i * 8 + 3, y + 4 + (i % 2) * 9, 1, 11, '#9a805d');
    }
    if (at(map, gx, gy - 1) !== 'bridge') {
      box(c, x, y, S, 5, '#554c40');box(c, x, y, S, 2, '#d4bc8b');
      box(c, x + 1, y - 2, 4, 10, '#9a805f');
    }
    if (at(map, gx, gy + 1) !== 'bridge') {
      box(c, x, y + 28, S, 4, '#675a45');box(c, x, y + 27, S, 2, '#d4bc8b');
      box(c, x + 27, y + 25, 4, 9, '#9a805f');
    }
  }
  function forest(c, x, y, gx, gy) {
    box(c, x + 2, y + 24, 29, 7, 'rgba(26,45,32,.35)');
    if (sheets.gardenTown) {
      // Two-part trees remain within the cell, leaving the unit's feet readable.
      const autumn = seed(gx, gy, 1) % 5 === 0;
      sprite(c, autumn ? 3 : 4, x + 1, y, 22, 18);
      sprite(c, autumn ? 15 : 16, x + 1, y + 18, 22, 14);
      sprite(c, 28, x + 16, y + 11, 16, 20);
    } else {
      box(c, x + 12, y + 18, 6, 14, '#65543c');
      box(c, x + 3, y + 4, 24, 19, '#385a3d');box(c, x + 7, y, 17, 20, '#648a4e');
    }
    // Deep green glaze brings the source palette closer to the muted garden.
    box(c, x, y, S, S, 'rgba(44,68,45,.10)');
  }
  function rock(c, x, y) {
    box(c, x + 3, y + 26, 27, 5, 'rgba(36,46,38,.3)');
    box(c, x + 5, y + 13, 23, 14, '#58685f');
    box(c, x + 9, y + 5, 15, 19, '#8f9b88');
    box(c, x + 10, y + 5, 13, 4, '#bdc3a5');
    box(c, x + 5, y + 14, 9, 9, '#a6ae95');
    box(c, x + 18, y + 12, 2, 14, '#687a6d');
    box(c, x + 5, y + 25, 11, 3, '#54744c');
  }
  function wall(c, map, gx, gy, x, y) {
    box(c, x + 3, y + 3, S, S, 'rgba(29,39,39,.26)');
    box(c, x, y, S, S, '#505c66');
    if (!sprite(c, 126, x, y + 5, S, 27)) {
      for (let i = 0; i < 4; i++) box(c, x + 1, y + i * 8 + 1, 30, 6, '#89979a');
    }
    box(c, x, y, S, 7, '#b3baad');box(c, x, y + 7, S, 2, '#485963');
    for (let i = 0; i < 3; i++) {
      box(c, x + i * 12, y, 7, 4, '#d0ceaf');
      box(c, x + i * 12, y + 4, 7, 2, '#8a9a96');
    }
    if (!stone(at(map, gx - 1, gy))) box(c, x, y + 8, 2, 24, '#c0c0a4');
    if (!stone(at(map, gx + 1, gy))) box(c, x + 29, y + 8, 3, 24, '#3e5159');
    if (gy === 1 && gx % 3 === 0 && gx > 11) {
      box(c, x + 11, y + 11, 10, 17, '#643f58');
      box(c, x + 15, y + 13, 2, 12, '#d4b77b');
    }
    if (seed(gx, gy, 75) % 3 === 0) {
      box(c, x + 3, y + 22, 3, 10, '#5e7750');box(c, x + 6, y + 25, 4, 3, '#7c905c');
    }
  }
  function chapel(c) {
    const x = S, y = S, w = 6 * S, h = 4 * S;
    box(c, x + 4, y + 7, w, h, 'rgba(23,36,37,.30)');
    box(c, x, y, w, h, '#4d6266');
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 13; col++) {
        const xx = x + col * 16 - (row % 2) * 8, yy = y + row * 9;
        c.save();c.beginPath();c.rect(x + 3, y + 3, w - 6, 85);c.clip();
        box(c, xx + 1, yy + 1, 14, 7, row % 2 ? '#587478' : '#65817e');
        box(c, xx + 1, yy + 1, 14, 1, '#8b9d89');c.restore();
      }
    }
    box(c, x, y + 86, w, 5, '#c3bea0');
    box(c, x, y + 91, w, 37, '#7b8681');
    box(c, x, y + 91, w, 4, '#414f57');
    for (let col = 0; col < 6; col++) {
      sprite(c, col === 2 ? 78 : 125, x + col * S + 7, y + 99, 19, 29);
    }
    box(c, x + 2, y + 126, w - 4, 2, '#c5bda0');
  }
  function draw(c, map) {
    c.save(); c.imageSmoothingEnabled = false;
    for (let gy = 0; gy < map.rows; gy++) {
      for (let gx = 0; gx < map.cols; gx++) {
        const x = gx * S, y = gy * S, type = at(map, gx, gy);
        ground(c, x, y, gx, gy);
        if (type === 'road') road(c, map, gx, gy, x, y);
        if (type === 'plaza' || type === 'gate' || type === 'gateOpen') paving(c, x, y, gx, gy);
        if (type === 'water') river(c, map, gx, gy, x, y);
        if (type === 'bridge') bridge(c, map, gx, gy, x, y);
        if (type === 'forest') forest(c, x, y, gx, gy);
        if (type === 'mountain') rock(c, x, y);
        if (type === 'wall') wall(c, map, gx, gy, x, y);
      }
    }
    chapel(c);
    // Fountain ornaments occupy blocked water cells exclusively.
    box(c, 16*S + 3, 4*S + 3, 2*S - 6, 4, '#d6cdb0');
    box(c, 16*S + 3, 6*S - 7, 2*S - 6, 4, '#b1b298');
    sprite(c, 32, 16*S + 14, 4*S + 9, 36, 34, true);
    box(c, 17*S - 1, 4*S + 26, 2, 18, '#a4d9c4');
    // Flower borders on forest cells reinforce the formal inner garden.
    for (const gx of [12,13,20,21]) {
      for (const gy of [4,5]) {
        for (let i=0;i<3;i++) {
          box(c, gx*S + 4+i*9, gy*S + 26, 3, 3, i%2 ? '#d9b4c1' : '#e1cea3');
        }
      }
    }
    // A subtle sunset treatment, baked once with the map cache.
    const light = c.createLinearGradient(0, 0, map.cols*S, map.rows*S);
    light.addColorStop(0, 'rgba(255,213,145,.14)');
    light.addColorStop(.55, 'rgba(235,182,126,.03)');
    light.addColorStop(1, 'rgba(32,49,68,.14)');
    c.fillStyle = light;c.fillRect(0,0,map.cols*S,map.rows*S);
    c.restore();
  }
  function drawGate(c, map, open) {
    c.save();
    for (let gy = 0; gy < map.rows; gy++) {
      for (let gx = 0; gx < map.cols; gx++) {
        if (!['gate','gateOpen'].includes(at(map,gx,gy))) continue;
        const x=gx*S, y=gy*S;
        paving(c,x,y,gx,gy);
        if (open) {
          box(c,x+2,y+2,3,27,'#48565a');box(c,x+3,y+3,1,25,'#c2a96a');
          box(c,x+27,y+2,3,27,'#48565a');box(c,x+28,y+3,1,25,'#c2a96a');
        } else {
          box(c,x,y+2,S,26,'#34454e');
          for (let i=0;i<5;i++) {box(c,x+3+i*6,y+3,2,23,'#b6b69b');box(c,x+5+i*6,y+3,1,23,'#53696b');}
          box(c,x,y+9,S,3,'#8c967f');box(c,x,y+23,S,3,'#8c967f');
          box(c,x+13,y+12,7,8,'#d7b66d');box(c,x+16,y+15,2,4,'#605747');
        }
        box(c,x,y,S,2,'#c6c2a1');
      }
    }
    c.restore();
  }
  function drawSample(c, type) {
    const map = {cols: 1, rows: 1, tiles: [[type]]};
    ground(c,0,0,0,0);
    if (type === 'road') road(c,map,0,0,0,0);
    if (type === 'plaza') paving(c,0,0,0,0);
    if (type === 'water') river(c,map,0,0,0,0);
    if (type === 'bridge') bridge(c,map,0,0,0,0);
    if (type === 'wall') wall(c,map,0,0,0,0);
    if (type === 'forest') forest(c,0,0,0,0);
    if (type === 'mountain') rock(c,0,0);
    if (type === 'gate' || type === 'gateOpen') drawGate(c,map,type === 'gateOpen');
  }
  MyGO.GardenMap = {load, draw, drawGate, drawSample};
})(window);

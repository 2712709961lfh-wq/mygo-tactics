'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
class AssetImage {
  set src(value) {
    this.file = value;
    const bytes = fs.readFileSync(path.join(root, value.split('?')[0]));
    this.width = this.naturalWidth = bytes.readUInt32BE(16);
    this.height = this.naturalHeight = bytes.readUInt32BE(20);
    queueMicrotask(() => this.onload());
  }
}
const window = { MyGO: { CONFIG: {}, Assets: {} } };
const scope = { window, Image: AssetImage, console, performance: { now: () => 0 } };
for (const file of ['characters', 'battle']) {
  vm.runInNewContext(fs.readFileSync(path.join(root, 'src', file + '.js'), 'utf8'), scope);
}
const calls = [];
const ctx = Object.fromEntries(['save', 'restore', 'translate', 'scale', 'drawImage', 'beginPath', 'ellipse', 'fill']
  .map(name => [name, (...args) => calls.push([name, ...args])]));
function draw(state, frame, facing = 'right', action) {
  calls.length = 0;
  assert(window.MyGO.Characters.drawBattlePose(ctx, { id: 'soyo' }, 12, 90, 90, state, frame, facing, action));
  return calls.find(x => x[0] === 'drawImage');
}
(async () => {
  const chars = window.MyGO.Characters;
  assert(await chars.load(), 'All real character PNGs must exist and load');
  assert(chars.hasActions('soyo'));
  assert(!chars.hasActions('tomori'));
  const meta = JSON.parse(fs.readFileSync(path.join(root, 'assets/characters/actions/soyo-actions.json')));
  assert.equal(meta.cellWidth, 320);
  assert.equal(meta.cellHeight, 208);
  assert.equal(Object.values(meta.frames).reduce((n, x) => n + x.count, 0), 35);
  let d = draw('attack', 6);
  assert(d[1].file.endsWith('soyo-actions.png'));
  assert.equal(d[2], 6 * 320);
  assert.equal(d[3], 0);
  const anchor = [d[6], d[7]];
  d = draw('attack', 5, 'right', 'flame');
  assert.equal(d[3], 208, 'Critical attack uses the flame-jet row');
  assert.deepEqual([d[6], d[7]], anchor, 'Casting frames share one foot anchor');
  d = draw('hurt', 4, 'left');
  assert.equal(d[3], 3 * 208);
  assert(calls.some(x => x[0] === 'scale' && x[1] === -1), 'Defender faces the attacker');
  d = draw('down', 999);
  assert.equal(d[2], 5 * 320, 'Down frame clamps to the final complete body');
  assert.equal(d[3], 4 * 208);
  assert.equal(draw('jump', 7)[3], 2 * 208);
  calls.length = 0;
  chars.drawMap(ctx, { id: 'soyo', facing: 'up' }, 0, 60, 60, 0);
  assert(calls.some(x => x[0] === 'drawImage' && x[1].file.includes('/idle/')), 'Map preserves true directional standing art');
  calls.length = 0;
  assert(chars.drawProjectile(ctx, { id: 'soyo' }, 100, 50, 24));
  assert(calls.some(x => x[0] === 'drawImage' && x[1].file.endsWith('soyo-fireball.png')));

  const scene = Object.create(window.MyGO.BattleScene.prototype);
  const poses = [];
  Object.assign(scene, { attacker: { id: 'soyo', weapon: { type: 'tome' } }, defender: { id: 'tomori' },
    result: { hit: true, crit: true, hpAfter: 10 },
    _shadow() {}, _sprite(...args) { poses.push(args); }, _drawWeaponFx() {}, _drawImpact() {}, _drawParticles() {} });
  scene._drawBattle(ctx, 0.30, -500);
  const early = poses[1][9];
  poses.length = 0;
  scene._drawBattle(ctx, 0.52, -100);
  assert(poses[1][9] > early, 'The battle clock advances the supplied casting frames');
  assert.equal(poses[1][10], 'flame');
  scene.attacker = { id: 'tomori', weapon: { type: 'sword' } };
  scene.defender = { id: 'soyo' };
  scene.result = { hit: false, hpAfter: 20 };
  poses.length = 0;
  scene._drawBattle(ctx, 0.70, 216);
  assert.equal(poses[0][8], 'jump', 'A missed hit plays the supplied jump sequence');
  scene.result = { hit: true, hpAfter: 0 };
  poses.length = 0;
  scene._drawBattle(ctx, 0.96, 684);
  assert.equal(poses[0][8], 'down');
  assert.equal(poses[0][9], 5);
  const flights = [];
  chars.drawProjectile = (...args) => flights.push(args);
  scene.attacker = { id: 'soyo' };
  for (const t of [0.40, 0.50, 0.70]) scene._drawMagicOrb(ctx, t, 142, 242, 434, 242);
  assert.equal(flights.length, 1, 'Painted projectile only exists between release and impact');
  console.log('Character actions: real assets, 35-frame metadata, anchors, facing, cast progression, critical jet, dodge, down and projectile timing passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
